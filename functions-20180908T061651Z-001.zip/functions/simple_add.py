x = float(input("x = "))
y = float(input("y = "))

print("{0} + {1} = {2}".format(x, y, x + y))
